Tracy Karol
Garrett Quintero
Clara Tran
App: ForeverToDo

Usage Instructions:
The app will bring up the task list view on launch with two buttons at the bottom that navigates to the other pages. "To Profile" will take you to the profile page, which will have a default image and username. To go back to the task list view, simply press the up arrow. "To History" will take you to the history page, which will also have a default image for the graph and a list of recent tasks completed or past its due date. Click on one of the tasks to view its details where all of its items are disabled until the Edit item is clicked. The up arrow will take you back to the task list page. To test the "Force Crash!" button, you must first press the sign out link in the preset profile, which will then take you to the Login page where the button is located. 

Known Bugs:
-"To Profile" will take you to a preset profile instead of the Login Page since the implementation to check if user is logged in or not is not set up yet
-Due date, time, notifications, and alarms are set up as EditText since the PickerDialogs are not set up yet
-Keyboard automatically pulls up when you click on a task to see its details

Specific areas for feedback:
-profile picture
-overall flow of the app, ignoring the profile bug
-task list design (e.g. if borders are needed, colors, etc)
-history page's setup with list being the only thing scrollable or to have the whole page scrollable
